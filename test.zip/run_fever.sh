mkdir files_fever_t/
mkdir files_fever_v/
mkdir files_fever_ts_t/
mkdir files_fever_ts_v/

pip install -U -r requirements.txt

wget https://fever.ai/download/fever/shared_task_dev.jsonl

wget https://fever.ai/download/fever/wiki-pages.zip
unzip /content/wiki-pages.zip

python src/create_knowledge_base.py fever

# LinUCB
python experiments/analysis.py fever
python src/train.py fever
python experiments/analysis_patched.py fever

python src/report_metrics.py fever
python src/report_metrics_patched.py fever

# Thompson Sampling
python experiments/analysis.py fever_ts
python src/train.py fever_ts
python experiments/analysis_patched.py fever_ts

python src/report_metrics.py fever_ts
python src/report_metrics_patched.py fever_ts

# Baselines
python src/report_metrics_patched.py fever_paraph
python src/report_metrics_patched.py fever_top20
python src/report_metrics_patched.py fever_bestarm

python src/train.py fever_nogate
python experiments/analysis_patched.py fever_nogate
python src/report_metrics_patched.py fever_nogate

python src/train.py fever_nocost
python experiments/analysis_patched.py fever_nocost
python src/report_metrics_patched.py fever_nocost

python experiments/analysis_posthoc.py fever
python src/report_metrics_patched.py fever_posthoc

python src/train.py fever_tb
python experiments/analysis_patched.py fever_tb
python src/report_metrics_patched.py fever_tb

python src/train.py fever_lb
python experiments/analysis_patched.py fever_lb
python src/report_metrics_patched.py fever_lb